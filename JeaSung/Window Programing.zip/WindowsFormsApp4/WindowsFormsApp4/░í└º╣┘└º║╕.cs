﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class 가위바위보 : Form
    {
        public int gw = 0;
        public int bw = 0;
        public int bo = 0;
        public int cgw = 0;
        public int cbw = 0;
        public int cbo = 0;
        public int w = 0;
        public int l = 0;
        public int t = 0;

        public 가위바위보()
        {
            InitializeComponent();
            Random a = new Random();
            int n = a.Next(0, 2);
            if (n == 0)
                cgw = cgw + 1;
            else if (n == 1)
                cbw = cbw + 1;
            else
                cbo = cbo + 1;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox4.Image = Properties.Resources.gawei;
            label4.Text = "가위";           
            Random a = new Random();
            int n = a.Next(0, 3);
            gw = gw + 1;
            label11.Text = gw.ToString();
            if (n==0)
            {
                pictureBox5.Image = Properties.Resources.gawei;
                label5.Text = "가위";
                t = t + 1;
                cgw = cgw + 1;
                label3.Text = "비겼어 !";
                label21.Text = t.ToString(); ;
                label17.Text = cgw.ToString() ;
            }
            else if(n==1)
            {
                pictureBox5.Image = Properties.Resources.bawei;
                label5.Text = "바위";
                l = l + 1;
                cbw = cbw + 1;
                label3.Text = "졌어 !";
                label22.Text = l.ToString(); 
                label16.Text = cbw.ToString();
            }
            else
            {
                pictureBox5.Image = Properties.Resources.bo;
                label5.Text = "보";
                w = w + 1;
                cbo = cbo + 1;
                label3.Text = "이겼어 !";
                label23.Text = w.ToString(); 
                label15.Text = cbo.ToString();
            }
                
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox4.Image = Properties.Resources.bawei;
            label4.Text = "바위";            
            Random a = new Random();
            int n = a.Next(0, 3);
            bw = bw + 1;
            label10.Text = bw.ToString();
            if (n == 0)
            {
                pictureBox5.Image= Properties.Resources.gawei;
                label5.Text = "가위";
                w = w + 1;
                cgw = cgw + 1;
                label3.Text = "이겼어 !";
                label17.Text = cgw.ToString();
                label23.Text = w.ToString();
            }
            else if (n == 1)
            {
                pictureBox5.Image = Properties.Resources.bawei;
                label5.Text = "바위";
                t = t + 1;
                cbw = cbw + 1;
                label3.Text = "비겼어 !";
                label16.Text = cbw.ToString();
                label21.Text = t.ToString(); 
            }
            else
            {
                pictureBox5.Image = Properties.Resources.bo;
                label5.Text = "보";
                l = l + 1;
                cbo = cbo + 1;
                label3.Text = "졌어 !";
                label15.Text = cbo.ToString();
                label22.Text = l.ToString();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pictureBox4.Image = Properties.Resources.bo;
            label4.Text = "보";           
            Random a = new Random();
            int n = a.Next(0, 2);
            bo = bo + 1;
            label9.Text = bo.ToString();
            if (n == 0)
            {
                pictureBox5.Image = Properties.Resources.gawei;
                label5.Text = "가위";
                l = l + 1;
                cgw = cgw + 1;
                label3.Text = "졌어 !";
                label17.Text = cgw.ToString();
                label22.Text = l.ToString();
            }
            else if (n == 1)
            {
                pictureBox5.Image = Properties.Resources.bawei;
                label5.Text = "바위";
                w = w + 1;
                cbw = cbw + 1;
                label3.Text = "이겼어 !";
                label23.Text = w.ToString();
                label16.Text = cbw.ToString();
            }
            else
            {
                pictureBox5.Image = Properties.Resources.bo;
                label5.Text = "보";
                t = t + 1;
                cbo = cbo + 1;
                label3.Text = "비겼어 !";
                label21.Text = t.ToString();
                label15.Text = cbo.ToString();
            }
        }

        
    }
}
