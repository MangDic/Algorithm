﻿namespace WindowsFormsApp5
{
    partial class quiz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(quiz));
            this.quiz1 = new System.Windows.Forms.GroupBox();
            this.q1r1 = new System.Windows.Forms.RadioButton();
            this.q1r2 = new System.Windows.Forms.RadioButton();
            this.a1 = new System.Windows.Forms.RadioButton();
            this.quiz2 = new System.Windows.Forms.GroupBox();
            this.a2 = new System.Windows.Forms.RadioButton();
            this.q2r2 = new System.Windows.Forms.RadioButton();
            this.q2r1 = new System.Windows.Forms.RadioButton();
            this.q1r3 = new System.Windows.Forms.RadioButton();
            this.q2r3 = new System.Windows.Forms.RadioButton();
            this.quiz3 = new System.Windows.Forms.GroupBox();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.q3r3 = new System.Windows.Forms.RadioButton();
            this.q3r2 = new System.Windows.Forms.RadioButton();
            this.q3r1 = new System.Windows.Forms.RadioButton();
            this.quiz4 = new System.Windows.Forms.GroupBox();
            this.q4r3 = new System.Windows.Forms.RadioButton();
            this.q4r2 = new System.Windows.Forms.RadioButton();
            this.a4 = new System.Windows.Forms.RadioButton();
            this.q4r1 = new System.Windows.Forms.RadioButton();
            this.quiz5 = new System.Windows.Forms.GroupBox();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.a5 = new System.Windows.Forms.RadioButton();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.quiz1.SuspendLayout();
            this.quiz2.SuspendLayout();
            this.quiz3.SuspendLayout();
            this.quiz4.SuspendLayout();
            this.quiz5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // quiz1
            // 
            this.quiz1.Controls.Add(this.q1r3);
            this.quiz1.Controls.Add(this.a1);
            this.quiz1.Controls.Add(this.q1r2);
            this.quiz1.Controls.Add(this.q1r1);
            this.quiz1.Location = new System.Drawing.Point(13, 13);
            this.quiz1.Name = "quiz1";
            this.quiz1.Size = new System.Drawing.Size(279, 129);
            this.quiz1.TabIndex = 0;
            this.quiz1.TabStop = false;
            this.quiz1.Text = "[문제 1] 우리나라 수도는?";
            // 
            // q1r1
            // 
            this.q1r1.AutoSize = true;
            this.q1r1.Location = new System.Drawing.Point(18, 25);
            this.q1r1.Name = "q1r1";
            this.q1r1.Size = new System.Drawing.Size(58, 19);
            this.q1r1.TabIndex = 0;
            this.q1r1.TabStop = true;
            this.q1r1.Text = "인천";
            this.q1r1.UseVisualStyleBackColor = true;
            // 
            // q1r2
            // 
            this.q1r2.AutoSize = true;
            this.q1r2.Location = new System.Drawing.Point(18, 50);
            this.q1r2.Name = "q1r2";
            this.q1r2.Size = new System.Drawing.Size(58, 19);
            this.q1r2.TabIndex = 1;
            this.q1r2.TabStop = true;
            this.q1r2.Text = "부산";
            this.q1r2.UseVisualStyleBackColor = true;
            // 
            // a1
            // 
            this.a1.AutoSize = true;
            this.a1.Location = new System.Drawing.Point(18, 75);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(58, 19);
            this.a1.TabIndex = 2;
            this.a1.TabStop = true;
            this.a1.Text = "서울";
            this.a1.UseVisualStyleBackColor = true;
            // 
            // quiz2
            // 
            this.quiz2.Controls.Add(this.q2r3);
            this.quiz2.Controls.Add(this.a2);
            this.quiz2.Controls.Add(this.q2r2);
            this.quiz2.Controls.Add(this.q2r1);
            this.quiz2.Location = new System.Drawing.Point(12, 148);
            this.quiz2.Name = "quiz2";
            this.quiz2.Size = new System.Drawing.Size(279, 120);
            this.quiz2.TabIndex = 1;
            this.quiz2.TabStop = false;
            this.quiz2.Text = "[문제 2] 인천에 있는 산은?";
            // 
            // a2
            // 
            this.a2.AutoSize = true;
            this.a2.Location = new System.Drawing.Point(18, 75);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(73, 19);
            this.a2.TabIndex = 2;
            this.a2.TabStop = true;
            this.a2.Text = "계양산";
            this.a2.UseVisualStyleBackColor = true;
            // 
            // q2r2
            // 
            this.q2r2.AutoSize = true;
            this.q2r2.Location = new System.Drawing.Point(18, 50);
            this.q2r2.Name = "q2r2";
            this.q2r2.Size = new System.Drawing.Size(73, 19);
            this.q2r2.TabIndex = 1;
            this.q2r2.TabStop = true;
            this.q2r2.Text = "백두산";
            this.q2r2.UseVisualStyleBackColor = true;
            // 
            // q2r1
            // 
            this.q2r1.AutoSize = true;
            this.q2r1.Location = new System.Drawing.Point(18, 25);
            this.q2r1.Name = "q2r1";
            this.q2r1.Size = new System.Drawing.Size(73, 19);
            this.q2r1.TabIndex = 0;
            this.q2r1.TabStop = true;
            this.q2r1.Text = "한라산";
            this.q2r1.UseVisualStyleBackColor = true;
            // 
            // q1r3
            // 
            this.q1r3.AutoSize = true;
            this.q1r3.Location = new System.Drawing.Point(18, 100);
            this.q1r3.Name = "q1r3";
            this.q1r3.Size = new System.Drawing.Size(58, 19);
            this.q1r3.TabIndex = 3;
            this.q1r3.TabStop = true;
            this.q1r3.Text = "부평";
            this.q1r3.UseVisualStyleBackColor = true;
            // 
            // q2r3
            // 
            this.q2r3.AutoSize = true;
            this.q2r3.Location = new System.Drawing.Point(18, 100);
            this.q2r3.Name = "q2r3";
            this.q2r3.Size = new System.Drawing.Size(73, 19);
            this.q2r3.TabIndex = 3;
            this.q2r3.TabStop = true;
            this.q2r3.Text = "금강산";
            this.q2r3.UseVisualStyleBackColor = true;
            // 
            // quiz3
            // 
            this.quiz3.Controls.Add(this.radioButton9);
            this.quiz3.Controls.Add(this.q3r3);
            this.quiz3.Controls.Add(this.q3r2);
            this.quiz3.Controls.Add(this.q3r1);
            this.quiz3.Location = new System.Drawing.Point(12, 274);
            this.quiz3.Name = "quiz3";
            this.quiz3.Size = new System.Drawing.Size(279, 120);
            this.quiz3.TabIndex = 6;
            this.quiz3.TabStop = false;
            this.quiz3.Text = "[문제 3] 끄아앙?";
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(18, 100);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(73, 19);
            this.radioButton9.TabIndex = 3;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "금강산";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // q3r3
            // 
            this.q3r3.AutoSize = true;
            this.q3r3.Location = new System.Drawing.Point(18, 75);
            this.q3r3.Name = "q3r3";
            this.q3r3.Size = new System.Drawing.Size(73, 19);
            this.q3r3.TabIndex = 2;
            this.q3r3.TabStop = true;
            this.q3r3.Text = "계양산";
            this.q3r3.UseVisualStyleBackColor = true;
            // 
            // q3r2
            // 
            this.q3r2.AutoSize = true;
            this.q3r2.Location = new System.Drawing.Point(18, 50);
            this.q3r2.Name = "q3r2";
            this.q3r2.Size = new System.Drawing.Size(73, 19);
            this.q3r2.TabIndex = 1;
            this.q3r2.TabStop = true;
            this.q3r2.Text = "백두산";
            this.q3r2.UseVisualStyleBackColor = true;
            // 
            // q3r1
            // 
            this.q3r1.AutoSize = true;
            this.q3r1.Location = new System.Drawing.Point(18, 25);
            this.q3r1.Name = "q3r1";
            this.q3r1.Size = new System.Drawing.Size(73, 19);
            this.q3r1.TabIndex = 0;
            this.q3r1.TabStop = true;
            this.q3r1.Text = "한라산";
            this.q3r1.UseVisualStyleBackColor = true;
            // 
            // quiz4
            // 
            this.quiz4.Controls.Add(this.q4r3);
            this.quiz4.Controls.Add(this.q4r2);
            this.quiz4.Controls.Add(this.a4);
            this.quiz4.Controls.Add(this.q4r1);
            this.quiz4.Location = new System.Drawing.Point(13, 400);
            this.quiz4.Name = "quiz4";
            this.quiz4.Size = new System.Drawing.Size(276, 45);
            this.quiz4.TabIndex = 7;
            this.quiz4.TabStop = false;
            this.quiz4.Text = "[문제 4] 1+1=?";
            // 
            // q4r3
            // 
            this.q4r3.AutoSize = true;
            this.q4r3.Location = new System.Drawing.Point(144, 25);
            this.q4r3.Name = "q4r3";
            this.q4r3.Size = new System.Drawing.Size(36, 19);
            this.q4r3.TabIndex = 3;
            this.q4r3.TabStop = true;
            this.q4r3.Text = "3";
            this.q4r3.UseVisualStyleBackColor = true;
            // 
            // q4r2
            // 
            this.q4r2.AutoSize = true;
            this.q4r2.Location = new System.Drawing.Point(102, 24);
            this.q4r2.Name = "q4r2";
            this.q4r2.Size = new System.Drawing.Size(36, 19);
            this.q4r2.TabIndex = 2;
            this.q4r2.TabStop = true;
            this.q4r2.Text = "5";
            this.q4r2.UseVisualStyleBackColor = true;
            // 
            // a4
            // 
            this.a4.AutoSize = true;
            this.a4.Location = new System.Drawing.Point(60, 24);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(36, 19);
            this.a4.TabIndex = 1;
            this.a4.TabStop = true;
            this.a4.Text = "2";
            this.a4.UseVisualStyleBackColor = true;
            // 
            // q4r1
            // 
            this.q4r1.AutoSize = true;
            this.q4r1.Location = new System.Drawing.Point(18, 25);
            this.q4r1.Name = "q4r1";
            this.q4r1.Size = new System.Drawing.Size(36, 19);
            this.q4r1.TabIndex = 0;
            this.q4r1.TabStop = true;
            this.q4r1.Text = "4";
            this.q4r1.UseVisualStyleBackColor = true;
            // 
            // quiz5
            // 
            this.quiz5.Controls.Add(this.pictureBox4);
            this.quiz5.Controls.Add(this.radioButton18);
            this.quiz5.Controls.Add(this.pictureBox3);
            this.quiz5.Controls.Add(this.a5);
            this.quiz5.Controls.Add(this.pictureBox2);
            this.quiz5.Controls.Add(this.pictureBox1);
            this.quiz5.Controls.Add(this.radioButton19);
            this.quiz5.Controls.Add(this.radioButton20);
            this.quiz5.Location = new System.Drawing.Point(348, 13);
            this.quiz5.Name = "quiz5";
            this.quiz5.Size = new System.Drawing.Size(408, 488);
            this.quiz5.TabIndex = 8;
            this.quiz5.TabStop = false;
            this.quiz5.Text = "[문제 5] 다이아 주은이 아닌 사람은?";
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Location = new System.Drawing.Point(197, 24);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(17, 16);
            this.radioButton19.TabIndex = 1;
            this.radioButton19.TabStop = true;
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(18, 25);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(17, 16);
            this.radioButton20.TabIndex = 0;
            this.radioButton20.TabStop = true;
            this.radioButton20.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(17, 47);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(174, 205);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(197, 46);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(174, 205);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // a5
            // 
            this.a5.AutoSize = true;
            this.a5.Location = new System.Drawing.Point(18, 258);
            this.a5.Name = "a5";
            this.a5.Size = new System.Drawing.Size(17, 16);
            this.a5.TabIndex = 6;
            this.a5.TabStop = true;
            this.a5.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(17, 280);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(174, 205);
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(197, 257);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(17, 16);
            this.radioButton18.TabIndex = 8;
            this.radioButton18.TabStop = true;
            this.radioButton18.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(366, 507);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "채점하기";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(561, 505);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(97, 25);
            this.textBox1.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(510, 511);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 11;
            this.label1.Text = "점수";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(197, 280);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(174, 205);
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(366, 537);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "나가기";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 601);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.quiz5);
            this.Controls.Add(this.quiz4);
            this.Controls.Add(this.quiz3);
            this.Controls.Add(this.quiz2);
            this.Controls.Add(this.quiz1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.quiz1.ResumeLayout(false);
            this.quiz1.PerformLayout();
            this.quiz2.ResumeLayout(false);
            this.quiz2.PerformLayout();
            this.quiz3.ResumeLayout(false);
            this.quiz3.PerformLayout();
            this.quiz4.ResumeLayout(false);
            this.quiz4.PerformLayout();
            this.quiz5.ResumeLayout(false);
            this.quiz5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox quiz1;
        private System.Windows.Forms.RadioButton q1r3;
        private System.Windows.Forms.RadioButton a1;
        private System.Windows.Forms.RadioButton q1r2;
        private System.Windows.Forms.RadioButton q1r1;
        private System.Windows.Forms.GroupBox quiz2;
        private System.Windows.Forms.RadioButton q2r3;
        private System.Windows.Forms.RadioButton a2;
        private System.Windows.Forms.RadioButton q2r2;
        private System.Windows.Forms.RadioButton q2r1;
        private System.Windows.Forms.GroupBox quiz3;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton q3r3;
        private System.Windows.Forms.RadioButton q3r2;
        private System.Windows.Forms.RadioButton q3r1;
        private System.Windows.Forms.GroupBox quiz4;
        private System.Windows.Forms.RadioButton q4r3;
        private System.Windows.Forms.RadioButton q4r2;
        private System.Windows.Forms.RadioButton a4;
        private System.Windows.Forms.RadioButton q4r1;
        private System.Windows.Forms.GroupBox quiz5;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.RadioButton a5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button button2;
    }
}