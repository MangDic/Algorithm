﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class quiz : Form
    {
        int sc = 0;
        public quiz()
        {
            InitializeComponent();
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (a1.Checked == true)
            {
                sc = sc + 1;
            }
            if (a2.Checked == true)
            {
                sc = sc + 1;
            }
            if (q3r2.Checked == true)
            {
                sc = sc + 1;
            }
            if (a4.Checked == true)
            {
                sc = sc + 1;
            }
            if (a5.Checked == true)
            {
                sc = sc + 1;
            }


            textBox1.Text = Convert.ToString(sc);
            sc = 0;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
