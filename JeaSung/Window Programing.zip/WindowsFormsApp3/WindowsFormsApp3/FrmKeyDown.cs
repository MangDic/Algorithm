﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FrmKeyDown : Form
    {
        private Point p;
        private Point o;
        private Point o1;
        private Point o2;
        private int src = 0;
        public FrmKeyDown()
        {
            InitializeComponent();
            p.X = 0; p.Y = 300;
            o.X = 0;
            o.Y = o1.Y = o2.Y = 40;
            o1.X = 100;
            o2.X = 200;

        }

        private void FrmKeyDown_Paint(object sender, PaintEventArgs e)
        {

            Random a = new Random();
            int s = a.Next(20, 280);
            e.Graphics.FillEllipse(Brushes.Blue, p.X, p.Y, 40, 40);
            e.Graphics.FillEllipse(Brushes.Red, o.X, o.Y, 40, 40);
            e.Graphics.FillEllipse(Brushes.Yellow, o1.X, o1.Y, 40, 40);
            e.Graphics.FillEllipse(Brushes.Purple, o2.X, o2.Y, 40, 40);
            if (p.X > 300)
            {
                p.X = 0;
                e.Graphics.FillEllipse(Brushes.Blue, p.X, p.Y, 40, 40);
            }
            else if (p.X < 0)
            {
                p.X = 300;
                e.Graphics.FillEllipse(Brushes.Blue, p.X, p.Y, 40, 40);
            }
            if (o.Y > 340)
            {
                o.Y = 40;
                o.X = s;
                e.Graphics.FillEllipse(Brushes.Blue, p.X, p.Y, 40, 40);
            }
            if (o1.Y > 340)
            {
                o1.Y = 40;
                o1.X = s;
                e.Graphics.FillEllipse(Brushes.Yellow, o1.X, o1.Y, 40, 40);
            }
            if (o2.Y > 340)
            {
                o2.Y = 40;
                o2.X = s;
                e.Graphics.FillEllipse(Brushes.RoyalBlue, o2.X, o2.Y, 40, 40);
            }
            if (p.X > o.X - 40 && p.X < o.X + 40 && p.Y > o.Y - 40 && p.Y < o.Y + 40)
            {
                src = src + 10;
                Score.Text = src.ToString();
                o.X = s; o.Y = 0;
                e.Graphics.FillEllipse(Brushes.Red, o.X, o.Y, 40, 40);

            }
            if (p.X > o1.X - 40 && p.X < o1.X + 40 && p.Y > o1.Y - 40 && p.Y < o1.Y + 40)
            {
                src = src + 10;
                Score.Text = src.ToString();
                o1.X = s; o1.Y = 0;
                e.Graphics.FillEllipse(Brushes.Yellow, o1.X, o1.Y, 40, 40);

            }
            if (p.X > o2.X - 40 && p.X < o2.X + 40 && p.Y > o2.Y - 40 && p.Y < o2.Y + 40)
            {
                src = src + 10;
                Score.Text = src.ToString();
                o2.X = s; o2.Y = 0;
                e.Graphics.FillEllipse(Brushes.Purple, o2.X, o2.Y, 40, 40);

            }
            if(o.Y>335 || o1.Y>335 || o2.Y>335)
            {
                if (o.Y > 335)
                    o.Y = 0;
                else if (o1.Y > 335)
                    o1.Y = 0;
                else
                    o2.Y = 0;
                src = src - 5;
                Score.Text = src.ToString();
            }
            if (src < -10)
            {
                MessageBox.Show("게임오버 ㅠㅠ");
                Application.Exit();
            }

        }

        private void FrmKeyDown_KeyDown(object sender, KeyEventArgs e)
        {


            switch (e.KeyCode)
            {
                case Keys.Left: { p.X -= 10; Invalidate(); break; }
                case Keys.Right:{ p.X += 10; Invalidate(); break; }
                case Keys.Escape: { MessageBox.Show("게임종료!");
                        Application.Exit(); break; }
                default:
                    break;
            }
            



        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            o.Y = o.Y + 1; o1.Y = o1.Y + 1; o2.Y = o2.Y + 1;
            Random a = new Random();
            int s = a.Next(0, 2);
            if (s == 1)
            {
                o.X = o.X + 1;
                o1.X = o1.X - 1;
            }
            else if (s == 2)
            {
                o1.X = o1.X - 1;
                o2.X = o2.X + 1;
            }
            else
                o2.X = o2.X - 1;
            Invalidate();
        }

    }

        
    }

       
