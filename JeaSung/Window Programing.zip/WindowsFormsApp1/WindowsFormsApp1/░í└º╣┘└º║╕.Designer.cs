﻿namespace WindowsFormsApp1
{
    partial class 가위바위보
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(가위바위보));
            this.Gawie = new System.Windows.Forms.PictureBox();
            this.Bawie = new System.Windows.Forms.PictureBox();
            this.Bo = new System.Windows.Forms.PictureBox();
            this.Compic = new System.Windows.Forms.PictureBox();
            this.Mypic = new System.Windows.Forms.PictureBox();
            this.Me = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Gawie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bawie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Compic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mypic)).BeginInit();
            this.SuspendLayout();
            // 
            // Gawie
            // 
            this.Gawie.Image = ((System.Drawing.Image)(resources.GetObject("Gawie.Image")));
            this.Gawie.Location = new System.Drawing.Point(12, 200);
            this.Gawie.Name = "Gawie";
            this.Gawie.Size = new System.Drawing.Size(100, 78);
            this.Gawie.TabIndex = 0;
            this.Gawie.TabStop = false;
            this.Gawie.Click += new System.EventHandler(this.Gawie_Click);
            // 
            // Bawie
            // 
            this.Bawie.Image = ((System.Drawing.Image)(resources.GetObject("Bawie.Image")));
            this.Bawie.Location = new System.Drawing.Point(135, 200);
            this.Bawie.Name = "Bawie";
            this.Bawie.Size = new System.Drawing.Size(100, 78);
            this.Bawie.TabIndex = 1;
            this.Bawie.TabStop = false;
            this.Bawie.Click += new System.EventHandler(this.Bawie_Click);
            // 
            // Bo
            // 
            this.Bo.Image = ((System.Drawing.Image)(resources.GetObject("Bo.Image")));
            this.Bo.Location = new System.Drawing.Point(254, 200);
            this.Bo.Name = "Bo";
            this.Bo.Size = new System.Drawing.Size(100, 78);
            this.Bo.TabIndex = 2;
            this.Bo.TabStop = false;
            this.Bo.Click += new System.EventHandler(this.Bo_Click);
            // 
            // Compic
            // 
            this.Compic.Location = new System.Drawing.Point(135, 102);
            this.Compic.Name = "Compic";
            this.Compic.Size = new System.Drawing.Size(100, 77);
            this.Compic.TabIndex = 4;
            this.Compic.TabStop = false;
            // 
            // Mypic
            // 
            this.Mypic.Location = new System.Drawing.Point(135, 12);
            this.Mypic.Name = "Mypic";
            this.Mypic.Size = new System.Drawing.Size(100, 77);
            this.Mypic.TabIndex = 5;
            this.Mypic.TabStop = false;
            this.Mypic.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // Me
            // 
            this.Me.AutoSize = true;
            this.Me.Location = new System.Drawing.Point(65, 52);
            this.Me.Name = "Me";
            this.Me.Size = new System.Drawing.Size(22, 15);
            this.Me.TabIndex = 6;
            this.Me.Text = "나";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "컴퓨터";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(283, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "결과";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // 가위바위보
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(874, 290);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Me);
            this.Controls.Add(this.Mypic);
            this.Controls.Add(this.Compic);
            this.Controls.Add(this.Bo);
            this.Controls.Add(this.Bawie);
            this.Controls.Add(this.Gawie);
            this.Name = "가위바위보";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Gawie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bawie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Compic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mypic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Gawie;
        private System.Windows.Forms.PictureBox Bawie;
        private System.Windows.Forms.PictureBox Bo;
        private System.Windows.Forms.PictureBox Compic;
        private System.Windows.Forms.PictureBox Mypic;
        private System.Windows.Forms.Label Me;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

