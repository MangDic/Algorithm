﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private string buffer; // 입력된 문자열들을 묶어줄 그릇     
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCommand_click(object sender, EventArgs e)
        {
            Button btn = sender as Button;

            #region 각각의 버튼 클릭시 해당 문자열을 buffer에 담기

            if (btn == btnOne)
            {
                buffer += "1";
            }
            else if (btn == btnTwo)
            {
                buffer += "2";
            }
            else if (btn == btnThree)
            {
                buffer += "3";
            }
            else if (btn == btnFour)
            {
                buffer += "4";
            }
            else if (btn == btnFive)
            {
                buffer += "5";
            }
            else if (btn == btnSix)
            {
                buffer += "6";
            }
            else if (btn == btnSeven)
            {
                buffer += "7";
            }
            else if (btn == btnEight)
            {
                buffer += "8";
            }
            else if (btn == btnNine)
            {
                buffer += "9";
            }
            else if (btn == btnZero)
            {
                buffer += "0";
            }
           
            else if (btn == btnPlus)
            {
                buffer += " + ";
            }
            else if (btn == btnMinus)
            {
                buffer += " - ";
            }
            else if (btn == btnMultiply)
            {
                buffer += " * ";
            }
           
            

            #endregion

            txtExpression.Text = buffer;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnClear_click(object sender, EventArgs e)
        {
            buffer = String.Empty;
            txtExpression.Text = "";
        }
    }
    }

