﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class 가위바위보 : Form
    {
        public 가위바위보()
        {
                      

        }

        public void pictureBox4_Click(object sender, EventArgs e)
        {
          
        }

        private void Gawie_Click(object sender, EventArgs e)
        {
            Random s = new Random();
            int r = s.Next(0, 2);
            int gic = 0;            
            Gawie.ImageLocation = "Images/gawei.jpg";
            if (r == 0)
                비김;
            else if (r == 1)
                짐;
            else
                이김;

        }

        private void Bawie_Click(object sender, EventArgs e)
        {          
            int bic = 0;
            Bawie.ImageLocation = "Images/gawei.jpg";
            

               

        }

        private void Bo_Click(object sender, EventArgs e)
        {
            int boc = 0;
            Bo.ImageLocation = "Images/gawei.jpg";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
