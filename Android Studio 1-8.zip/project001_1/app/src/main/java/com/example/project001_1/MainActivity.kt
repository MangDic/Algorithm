package com.example.project001_1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun addClick(v: View) {
        val number1 = findViewById<View>(R.id.number1) as EditText
        val number2 = findViewById<View>(R.id.number2) as EditText
        val result = findViewById<View>(R.id.Result) as TextView
        val n1 = Integer.parseInt(number1.text.toString())
        val n2 = Integer.parseInt(number2.text.toString())
        result.text = Integer.toString(n1 + n2)
    }

    fun subtractClick(v: View) {
        val number1 = findViewById<View>(R.id.number1) as EditText
        val number2 = findViewById<View>(R.id.number2) as EditText
        val result = findViewById<View>(R.id.Result) as TextView
        val n1 = Integer.parseInt(number1.text.toString())
        val n2 = Integer.parseInt(number2.text.toString())
        result.text = Integer.toString(n1 - n2)
    }

    fun multiplyClick(v: View) {
        val number1 = findViewById<View>(R.id.number1) as EditText
        val number2 = findViewById<View>(R.id.number2) as EditText
        val result = findViewById<View>(R.id.Result) as TextView
        val n1 = Integer.parseInt(number1.text.toString())
        val n2 = Integer.parseInt(number2.text.toString())
        result.text = Integer.toString(n1 * n2)
    }

    fun divideClick(v: View) {
        val number1 = findViewById<View>(R.id.number1) as EditText
        val number2 = findViewById<View>(R.id.number2) as EditText
        val result = findViewById<View>(R.id.Result) as TextView
        val n1 = Integer.parseInt(number1.text.toString())
        val n2 = Integer.parseInt(number2.text.toString())
        result.text = Integer.toString(n1 / n2)
    }
}
